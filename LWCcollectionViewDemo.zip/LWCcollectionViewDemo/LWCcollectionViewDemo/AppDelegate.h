//
//  AppDelegate.h
//  LWCcollectionViewDemo
//
//  Created by 张晴顺 on 2017/6/1.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

