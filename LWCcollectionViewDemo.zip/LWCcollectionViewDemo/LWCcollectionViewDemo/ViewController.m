//
//  ViewController.m
//  LWCcollectionViewDemo
//
//  Created by 张晴顺 on 2017/6/1.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "ViewController.h"
#import "ZKCitySeverViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    
}
- (IBAction)NextClick:(id)sender {
    
    ZKCitySeverViewController *VC=[ZKCitySeverViewController new];
    
//    [self.navigationController pushViewController:VC animated:YES];
    
    [self presentViewController:VC animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
