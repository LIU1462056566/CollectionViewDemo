//
//  ZKCitySeverCollectionViewCell.m
//  ZKNormalTest_01_1
//
//  Created by 张晴顺 on 2017/5/25.
//  Copyright © 2017年 众开. All rights reserved.
//

#import "ZKCitySeverContentCollectionViewCell.h"
#import "Masonry.h"
@implementation ZKCitySeverContentCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        self.backgroundColor=[UIColor whiteColor];
        self.layer.borderWidth=.5;
        self.layer.borderColor=[UIColor blackColor].CGColor;
        
        _titleLable=[[UILabel alloc]init];
        [self addSubview:_titleLable];
        _titleLable.lineBreakMode=NSLineBreakByTruncatingMiddle;
        _titleLable.font=[UIFont systemFontOfSize:14];
        _titleLable.textAlignment=YES;
        
        
        [_titleLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.centerY.equalTo(self.mas_centerY);
            make.width.offset(([UIScreen mainScreen].bounds.size.width-50)/4);
        }];
        
        
    }return self;
}


@end
