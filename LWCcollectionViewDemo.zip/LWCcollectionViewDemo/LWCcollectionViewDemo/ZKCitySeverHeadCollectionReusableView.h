//
//  ZKCitySeverHeadCollectionReusableView.h
//  ZKNormalTest_01_1
//
//  Created by 张晴顺 on 2017/5/25.
//  Copyright © 2017年 众开. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZKCitySeverHeadCollectionReusableView : UICollectionReusableView

@property(nonatomic,strong)UILabel *titleLable;

@end
