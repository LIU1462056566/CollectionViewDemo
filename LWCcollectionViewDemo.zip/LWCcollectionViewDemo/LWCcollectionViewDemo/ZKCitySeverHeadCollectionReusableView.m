//
//  ZKCitySeverHeadCollectionReusableView.m
//  ZKNormalTest_01_1
//
//  Created by 张晴顺 on 2017/5/25.
//  Copyright © 2017年 众开. All rights reserved.
//

#import "ZKCitySeverHeadCollectionReusableView.h"
#import "Masonry.h"
@implementation ZKCitySeverHeadCollectionReusableView

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        self.backgroundColor=[UIColor darkGrayColor];
        
        _titleLable=[[UILabel alloc]init];
        [self addSubview:_titleLable];
        _titleLable.font=[UIFont systemFontOfSize:16];
        
        
        [_titleLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.offset(10);
            make.centerY.equalTo(self.mas_centerY);
        }];
        
        
    }return self;
}


@end
