//
//  ZKCitySeverViewController.m
//  ZKNormalTest_01_1
//
//  Created by 张晴顺 on 2017/5/25.
//  Copyright © 2017年 众开. All rights reserved.
//



#define SCREENW    ([[UIScreen mainScreen] bounds].size.width)

#define SCREENH    ([[UIScreen mainScreen] bounds].size.height)
//control-----------
#import "ZKCitySeverViewController.h"
//#import "LXGNetWorkQuery.h"

//model----------

//#import "ZKCityProSeverModel.h"
//#import "ZKcitySeverContentModel.h"


//view---------
#import "ZKCitySeverHeadCollectionReusableView.h"
#import "ZKCitySeverContentCollectionViewCell.h"

//other---------


@interface ZKCitySeverViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property(nonatomic,strong)UICollectionView *myCollectionView;

@property(nonatomic,strong)NSMutableArray *dataArr;
@end

@implementation ZKCitySeverViewController
-(NSMutableArray *)dataArr
{
    if (!_dataArr) {
        _dataArr=[[NSMutableArray alloc]init];
    }return _dataArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    [self.view addSubview:self.myCollectionView];
    
//    [self loadData];
    
}

//-(void)loadData
//{
//    __weak ZKCitySeverViewController *weakSelf1 = self;
//    LXGNetWorkQuery *lxg = [LXGNetWorkQuery shareManager];
//    [SVProgressHUD show];
//    [lxg AFrequestData:@"finance/linked/querySysProvinceArea" HttpMethod:@"GET" params:nil completionHandle:^(id result) {
//      
//        if ([result[@"msg"] isEqualToString:@"查询信息成功"]) {
//            NSArray *classArr=result[@"datas"];
//            
//            
//            for (NSDictionary *dict in classArr) {
//                ZKcitySeverContentModel *model=[ZKcitySeverContentModel mj_objectWithKeyValues:dict];
//                [ZKcitySeverContentModel mj_replacedKeyFromPropertyName];
//                [ZKcitySeverContentModel mj_objectClassInArray];
//                [weakSelf1.dataArr addObject:model];
//            }
//            
//            
//            
//            
//            [SVProgressHUD dismiss];
//        }else{
//           [SVProgressHUD dismiss];
//        }
//        
//            
//      
//        [weakSelf1.myCollectionView reloadData];
//        
//    } errorHandle:^(NSError *result) {
//        [weakSelf1 showMessage:@"网络错误"];
//        [SVProgressHUD dismiss];
//    }];
//
//}

-(UICollectionView *)myCollectionView
{
    if (!_myCollectionView) {
        UICollectionViewFlowLayout *FlayOut=[[UICollectionViewFlowLayout alloc]init];
        FlayOut.scrollDirection=UICollectionViewScrollDirectionVertical;
        FlayOut.minimumLineSpacing=10;
        FlayOut.minimumInteritemSpacing=10;
        _myCollectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(0, 64, SCREENW, SCREENH-64) collectionViewLayout:FlayOut];
        _myCollectionView.delegate=self;
        _myCollectionView.dataSource=self;
        [_myCollectionView registerClass:[ZKCitySeverContentCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
        [_myCollectionView registerClass:[ZKCitySeverHeadCollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"firstHead"];
        _myCollectionView.backgroundColor=[UIColor whiteColor];
    }return _myCollectionView;
}
//collectionview  代理方法
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section
{
    return CGSizeMake(.1, .1);
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(SCREENW, 40);
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((SCREENW-50)/4, 30);
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
//     ZKcitySeverContentModel *model=self.dataArr[section];
//    return model.provinces.count;
    
    return arc4random()%16;
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
//    return self.dataArr.count;
    return 10;
}
-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    ZKCitySeverHeadCollectionReusableView *reuseableView=[collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"firstHead" forIndexPath:indexPath];
//    ZKcitySeverContentModel *model=self.dataArr[indexPath.section];
//    if (![model.areaName isKindOfClass:[NSNull class]]) {
//        reuseableView.titleLable.text=model.areaName;
//    }
    int i=arc4random()%100;
     reuseableView.titleLable.text=[NSString stringWithFormat:@"江西省%d",i];
    return reuseableView;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ZKCitySeverContentCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
//    ZKcitySeverContentModel *model=self.dataArr[indexPath.section];
//    ZKCityProSeverModel *model1=model.provinces[indexPath.item];
//    cell.titleLable.text=model1.name;
//    if ([model1.isSelect isEqualToString:@"1"]) {
//        cell.backgroundColor=[UIColor redColor];
//        cell.titleLable.textColor=[UIColor blueColor];
//    }else{
//       cell.backgroundColor=[UIColor whiteColor];
//        cell.titleLable.textColor=[UIColor blackColor];
//    }
     int i=arc4random()%10;
    cell.backgroundColor=[UIColor whiteColor];
    cell.titleLable.textColor=[UIColor blackColor];
    cell.titleLable.text=[NSString stringWithFormat:@"南昌%d",i];
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
//    ZKCitySeverContentCollectionViewCell *cell=(ZKCitySeverContentCollectionViewCell*)[collectionView cellForItemAtIndexPath:indexPath];
    
//    ZKcitySeverContentModel *model=self.dataArr[indexPath.section];
//    ZKCityProSeverModel *model1=model.provinces[indexPath.item];
//    if ([model1.isSelect isEqualToString:@"1"]) {
//        model1.isSelect=@"2";
//        cell.titleLable.textColor=[UIColor blackColor];
//        cell.backgroundColor=[UIColor whiteColor];
//    }else{
//        model1.isSelect=@"1";
//        cell.titleLable.textColor=[UIColor blueColor];
//        cell.backgroundColor=[UIColor redColor];
//    }
    
//   
//    UIAlertController *alertControl=[UIAlertController alertControllerWithTitle:[NSString stringWithFormat:@"省份ID%@",model1.ProID] message:[NSString stringWithFormat:@"您点击了%ld区%ld行",indexPath.section,indexPath.row ] preferredStyle:UIAlertControllerStyleAlert];
//    UIAlertAction *action2=[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
//        
//    }];
//    [alertControl addAction:action2];
//    [self presentViewController:alertControl animated:YES completion:nil];
    
    NSLog(@"secon---%ld-----row-----%ld",indexPath.section,indexPath.row);
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
